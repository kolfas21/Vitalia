package com.diagnosticos.Vitalia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitaliaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VitaliaApplication.class, args);
	}

}


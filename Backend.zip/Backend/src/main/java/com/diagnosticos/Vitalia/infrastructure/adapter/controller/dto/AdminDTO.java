// AdminDTO.java
package com.diagnosticos.Vitalia.infrastructure.adapter.controller.dto;

import lombok.Data;

@Data
public class AdminDTO {
    private String nombre;
    private String correo;
    private String cedula;
    private String contrasena;
}
